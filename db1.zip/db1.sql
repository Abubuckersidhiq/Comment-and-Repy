-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 23, 2022 at 03:35 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db1`
--

-- --------------------------------------------------------

--
-- Table structure for table `tabcomments`
--

CREATE TABLE `tabcomments` (
  `commentid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `commentdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabcomments`
--

INSERT INTO `tabcomments` (`commentid`, `username`, `comment`, `commentdate`) VALUES
(1, 'Arun', 'Wow!', '2022-04-23 12:46:29'),
(2, 'Bala', 'Super', '2022-04-23 12:46:37');

-- --------------------------------------------------------

--
-- Table structure for table `tabreplies`
--

CREATE TABLE `tabreplies` (
  `replyid` int(11) NOT NULL,
  `commentid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `reply` varchar(500) NOT NULL,
  `replydate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabreplies`
--

INSERT INTO `tabreplies` (`replyid`, `commentid`, `username`, `reply`, `replydate`) VALUES
(1, 1, 'Arun', 'thank you!', '2022-04-23 13:12:41'),
(2, 1, 'Kumar', 'Hello', '2022-04-23 13:19:15'),
(4, 2, 'Ravi', 'Fine', '2022-04-23 13:20:25'),
(5, 2, 'Ajey', 'Superb', '2022-04-23 13:26:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tabcomments`
--
ALTER TABLE `tabcomments`
  ADD PRIMARY KEY (`commentid`);

--
-- Indexes for table `tabreplies`
--
ALTER TABLE `tabreplies`
  ADD PRIMARY KEY (`replyid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tabcomments`
--
ALTER TABLE `tabcomments`
  MODIFY `commentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tabreplies`
--
ALTER TABLE `tabreplies`
  MODIFY `replyid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
